import { useAuthContext } from "../../context/AuthContext";
import { extractTime } from "../../utils/extractTime";
import useConversation from "../../zustand/useConversation";

// const API_URL = 'http://10.2.44.52:8888/api';
const API_URL = 'http://127.0.0.1:8888/api';

const Message = ({ message }) => {
    const { authUser } = useAuthContext();
    const { selectedConversation } = useConversation();
    const fromMe = message.MessageType === 1;
    const formattedTime = extractTime(message.CreatedAt);
    const chatClassName = fromMe ? "chat-end" : "chat-start";
    const profilePic = fromMe ? `${API_URL}/images/${authUser.Avatar}` : `${API_URL}/images/${selectedConversation?.Avatar}`;
    const bubbleBgColor = fromMe ? "bg-blue-500" : "";

    return (
        <div className={`chat ${chatClassName}`}>
            <div className='chat-image avatar'>
                <div className='w-10 rounded-full'>
                    <img alt='User avatar' src={profilePic} />
                </div>
            </div>
            <div className={`chat-bubble text-white ${bubbleBgColor} pb-2`}>
                {message.Content || "Image message"}
                {message.Images && message.Images.length > 0 && (
                    <div>
                        {message.Images.map((image) => (
                            <img key={image._id} src={`${API_URL}${image.urlImage}`} alt={image.FileName} className="w-full" />
                        ))}
                    </div>
                )}
            </div>
            <div className='chat-footer opacity-50 text-xs flex gap-1 items-center'>{formattedTime}</div>
        </div>
    );
};

export default Message;

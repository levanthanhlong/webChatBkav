import { useState, useMemo } from "react";
import { IoSearchSharp } from "react-icons/io5";
import useConversation from "../../zustand/useConversation";

import toast from "react-hot-toast";
import React from 'react';
import UserMenu from "./UserMenu";
import useGetConversations from "../../hooks/useGetConversations";

const SearchInput = () => {
	const [search, setSearch] = useState("");
	const { setSelectedConversation } = useConversation();
	const { conversations } = useGetConversations();

	const debouncedSearch = useMemo(() => {
		let timeoutId;
		return (value) => {
			clearTimeout(timeoutId);
			timeoutId = setTimeout(() => setSearch(value), 300);
		};
	}, []);

	const handleSubmit = (e) => {
		e.preventDefault();
		if (!search) return;
		if (search.length < 3) {
			return toast.error("Search term must be at least 3 characters long");
		}

		const conversation = conversations.find((c) =>
			c.FullName.toLowerCase().includes(search.toLowerCase())
		);

		if (conversation) {
			setSelectedConversation(conversation);
			setSearch("");
		} else {
			toast.error("No such user found!");
		}
	};

	return (
		<div className="flex flex-row gap-4">
			<UserMenu/>
			<form onSubmit={handleSubmit} className="flex items-center p-1 border rounded-full bg-white shadow">
				<div className="pl-2">
					<IoSearchSharp className="w-4 h-4 text-gray-400" />
				</div>
				<input
					type="text"
					placeholder="Tìm kiếm"
					className="flex-1 p-1 bg-transparent focus:outline-none rounded-full"
					onChange={(e) => debouncedSearch(e.target.value)}
				/>
			</form>

		</div>
		
	  );
};

export default SearchInput;

import { useState } from "react";
import useConversation from "../zustand/useConversation";
import toast from "react-hot-toast";
import axios from "axios";

const API_URL = 'http://10.2.44.52:8888/api';

// const API_URL = 'http://127.0.0.1:8888/api';

const useSendMessage = () => {
    const [loading, setLoading] = useState(false);
    const { setMessages, selectedConversation } = useConversation();

    const sendMessage = async (message) => {
        setLoading(true);
        try {
            const token = JSON.parse(localStorage.getItem("chat-user")).token;
            const res = await axios.post(`${API_URL}/message/send-message`, {
                FriendID: selectedConversation.FriendID,
                Content: message,
                files: [] // Assuming no file is sent, handle file upload as needed
            }, {
                headers: {
                    "Authorization": `Bearer ${token}`,
                    "Content-Type": "multipart/form-data"
                }
            });
            const data = res.data;
            if (data.status !== 1) throw new Error(data.message || "Failed to send message");

            setMessages((prevMessages) => [...prevMessages, data.data]);
        } catch (error) {
            toast.error(error.message);
        } finally {
            setLoading(false);
        }
    };

    return { sendMessage, loading };
};

export default useSendMessage;

import { useState } from "react";
import toast from "react-hot-toast";
import axios from "axios";

const API_URL = 'http://10.2.44.52:8888/api';

const useUpdateUserInfo = () => {
    const [loading, setLoading] = useState(false);

    const updateUserInfor = async (fullName, avatarFile) => {
        setLoading(true);
        try {
            const storedUser = localStorage.getItem("chat-user");
            if (!storedUser) {
                alert('token khong ton tai')
                throw new Error("Token không tồn tại");
            }

            alert('dang check token');

            const { token } = JSON.parse(storedUser);
            if (!token){
                alert('token khong hop le');
                throw new Error("Token không hợp lệ");
            } 
            
            alert('token  ton tai');

            const formData = new FormData();
            formData.append("FullName", fullName);
            formData.append("Avatar", avatarFile);

            const res = await axios.post(`${API_URL}/user/update`, formData, {
                headers: {
                    "Authorization": `Bearer ${token}`,
                }
            });
            
            alert('ket noi duoc api');
            const data = res.data;
            if (data.status !== 1) {
                alert('khong cap nhat duoc data');
                throw new Error(data.message || "Cập nhật thông tin người dùng thất bại");
                
            }

            alert('cap nhat duoc data');
            toast.success(data.message || "Cập nhật thông tin người dùng thành công");
        } catch (error) {
            console.error("Cập nhật thông tin người dùng thất bại", error);
            toast.error(error.message || "Đã xảy ra lỗi khi cập nhật thông tin người dùng");
        } finally {
            setLoading(false);
        }
    };

    return { loading, updateUserInfor };
};

export default useUpdateUserInfo;

import useGetConversations from "../../hooks/useGetConversations";
import Conversation from "./Conversation";

const Conversations = ({ search }) => {
  const { loading, conversations } = useGetConversations();

  // Lọc các cuộc hội thoại mà FullName có chứa chuỗi tìm kiếm
  const filteredConversations = search
    ? conversations.filter((conversation) =>
        String(conversation.FullName)
          .toLowerCase()
          .includes(search.toLowerCase())
      )
    : conversations;
      
  return (
    <div className="py-2 flex flex-col overflow-auto">
      {filteredConversations.map((conversation, idx) => (
        <Conversation
          key={conversation.FriendID}
          conversation={conversation}
          lastIdx={idx === filteredConversations.length - 1}
        />
      ))}

      {loading ? (
        <span className="loading loading-spinner mx-auto"></span>
      ) : null}
    </div>
  );
};

export default Conversations;

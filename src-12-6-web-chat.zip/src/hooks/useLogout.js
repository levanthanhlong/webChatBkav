import { useState } from "react";
import { useAuthContext } from "../context/AuthContext";
import toast from "react-hot-toast";

const useLogout = () => {
    const [loading, setLoading] = useState(false);
    const { setAuthUser } = useAuthContext();

    const logout = async () => {
        setLoading(true);
        try {
            // Xóa thông tin người dùng khỏi localStorage
            localStorage.removeItem("chat-user");
            // Cập nhật trạng thái xác thực
            setAuthUser(null);
            toast.success("Logout successful");
        } catch (error) {
            toast.error("Logout failed");
        } finally {
            setLoading(false);
        }
    };

    return { loading, logout };
};

export default useLogout;

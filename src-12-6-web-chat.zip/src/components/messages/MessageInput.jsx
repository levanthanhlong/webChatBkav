import { useState } from "react";
import { BsSend } from "react-icons/bs";
import useSendMessage from "../../hooks/useSendMessage";
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import toast from "react-hot-toast";

const MessageInput = () => {
    const [message, setMessage] = useState("");
    const [file, setFile] = useState(null);
    const { loading, sendMessage } = useSendMessage();

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!message && !file) return;
        toast.success("Sending message...");
        await sendMessage(message, file);
        setMessage("");
        setFile(null);
    };

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
        toast.success("File selected");
    };

    return (
        <form className='px-4 my-3' onSubmit={handleSubmit}>
            <div className='w-full relative flex gap-4 justify-center items-center'>
                <input
                    type="file"
                    id="fileInput"
                    style={{ display: 'none' }}
                    onChange={handleFileChange}
                />
                <button
                    type="button"
                    onClick={() => document.getElementById('fileInput').click()}
                >
                    <AddCircleOutlineIcon />
                </button>
                <input
                    type='text'
                    className='border text-sm rounded-lg block w-full p-2.5 bg-gray-100 border-gray-600 text-black'
                    placeholder='Send a message'
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                />
                <button type='submit' className='absolute inset-y-0 end-0 flex items-center pe-3'>
                    {loading ? <div className='loading loading-spinner'></div> : <BsSend />}
                </button>
            </div>
        </form>
    );
};
export default MessageInput;

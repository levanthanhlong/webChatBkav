// import React, { useState, useRef } from 'react';
// import MenuIcon from '@mui/icons-material/Menu';
// import LogoutButton from './LogoutButton';
// import useGetUserInfor from '../../hooks/useGetInforUser';
// import useUpdateUserInfor from '../../hooks/useUpdateUserInfor';

// const UserMenu = () => {
//   const [isMenuOpen, setIsMenuOpen] = useState(false);
//   const [isDarkMode, setIsDarkMode] = useState(false);
//   const { userInfor } = useGetUserInfor();
//   const { loading, updateUserInfor } = useUpdateUserInfor();
//   const fileInputRef = useRef(null);

//   const API_URL = 'http://10.2.44.52:8888/api/';

//   const toggleMenu = () => {
//     setIsMenuOpen(!isMenuOpen);
//   };

//   const toggleDarkMode = () => {
//     setIsDarkMode(!isDarkMode);
//     document.documentElement.classList.toggle('dark');
//     alert('dieu chinh che do sang/toi')
//   };

//   const handleAvatarClick = () => {
//     fileInputRef.current.click();
//   };

//   const handleFileChange = (event) => {
//     alert('dang check image');
//     const file = event.target.files[0];
//     if (file) {
//       alert('co image');
//       updateUserInfor(userInfor.FullName, file);
//     }
//   };
  
//   return (
//     <div className="relative">
//       <button
//         onClick={toggleMenu}
//         className="flex items-center space-x-2 focus:outline-none"
//       >
//         <MenuIcon />
//       </button>
//       {isMenuOpen && (
//         <div className="absolute mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg overflow-hidden z-20">
//           <div
//             className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer"
//             onClick={handleAvatarClick}
//           >
//             <div className="flex gap-2 items-center rounded p-2 py-1">
//               <div className="w-12 rounded-full">
//                 <img src={`${API_URL}images/${userInfor.Avatar}`} alt='user avatar' />
//               </div>
//               <div className='flex flex-col flex-1'>
//                 <div className='flex gap-3 justify-between'>
//                   <p className='font-bold text-black'>{userInfor.FullName}</p>
//                 </div>
//               </div>
//             </div>
//           </div>
//           <a
//             href="#"
//             className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600"
//           >
//             @ Nhắc đến bạn
//           </a>
//           <a
//             href="#"
//             className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600"
//           >
//             Tạo nhóm
//           </a>
//           <div className="px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100">
//             <label htmlFor="toggleDarkMode" className="flex items-center cursor-pointer">
//               <span className="mr-2">Giao diện tối</span>
//               <div className="w-10 h-4 relative bg-gray-400 rounded-full shadow-inner dark:bg-gray-600 items">
//                 <div
//                   className={`dot absolute w-6 h-6 bg-white rounded-full shadow inset-y-0 left-0 transition-transform duration-300 ease-in-out ${isDarkMode ? 'transform translate-x-full bg-gray-800' : ''}`}
//                 >
//                   <input
//                     id="toggleDarkMode"
//                     type="checkbox"
//                     checked={isDarkMode}
//                     onChange={toggleDarkMode}
//                     className="toggle-checkbox hidden"
//                   />
//                 </div>
//               </div>
//             </label>
//           </div>
//           <div className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer">
//             <LogoutButton />
//           </div>
//         </div>
//       )}
//       <input
//         type="file"
//         ref={fileInputRef}
//         style={{ display: 'none' }}
//         accept="image/*"
//         onChange={handleFileChange}
//       />
//     </div>
//   );
// };

// export default UserMenu;

import { useState, useRef } from 'react';
import MenuIcon from '@mui/icons-material/Menu';
import LogoutButton from './LogoutButton';
import useGetInforUser from '../../hooks/useGetInforUser';
import useUpdateUserInfor from '../../hooks/useUpdateUserInfor';
import toast, { Toaster } from 'react-hot-toast';

const UserMenu = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const { userInfor } = useGetInforUser();
  const { loading, updateUserInfo } = useUpdateUserInfor();
  const fileInputRef = useRef(null);

  const API_URL = 'http://10.2.44.52:8888/api/';

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
    toast.success('Đã chuyển chế độ sáng/tối');
  };

  const handleAvatarClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      if (file.size < 2000000) { // Kiểm tra kích thước file
        updateUserInfo(userInfor.FullName, file);
        setTimeout(() => {
          window.location.reload();
        }, 100);
      } else {
        alert("Image size must be less than 2MB");
      }
    }
  };

  return (
    <div className="relative">
      <button
        onClick={toggleMenu}
        className="flex items-center space-x-2 focus:outline-none"
      >
        <MenuIcon />
      </button>
      {isMenuOpen && (
        <div className="absolute mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg overflow-hidden z-20">
          <div
            className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer"
            onClick={handleAvatarClick}
          >
            <div className="flex gap-2 items-center rounded p-2 py-1">
              <div className="w-12 rounded-full">
                <img src={`${API_URL}/images/${userInfor.Avatar}`} alt='user avatar' />
              </div>
              <div className='flex flex-col flex-1'>
                <div className='flex gap-3 justify-between'>
                  <p className='font-bold text-black dark:text-white'>{userInfor.FullName}</p>
                </div>
              </div>
            </div>
          </div>
          <a
            href="#"
            className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600"
          >
            @ Nhắc đến bạn
          </a>
          <a
            href="#"
            className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600"
          >
            Tạo nhóm
          </a>
          <div className="px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100">
            <label htmlFor="toggleDarkMode" className="flex items-center cursor-pointer">
              <span className="mr-2">Giao diện tối</span>
              <div className="w-10 h-4 relative bg-gray-400 rounded-full shadow-inner dark:bg-gray-600">
                <div
                  className={`dot absolute w-6 h-6 bg-white rounded-full shadow inset-y-0 left-0 transition-transform duration-300 ease-in-out ${isDarkMode ? 'transform translate-x-full bg-gray-800' : ''}`}
                />
                <input
                  id="toggleDarkMode"
                  type="checkbox"
                  checked={isDarkMode}
                  onChange={toggleDarkMode}
                  className="toggle-checkbox hidden"
                />
              </div>
            </label>
          </div>
          <div className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer">
            <LogoutButton />
          </div>
        </div>
      )}
      <input
        type="file"
        ref={fileInputRef}
        style={{ display: 'none' }}
        accept="image/*"
        onChange={handleFileChange}
      />
      <Toaster />
      {loading && <div>Đang cập nhật...</div>}
    </div>
  );
};

export default UserMenu;

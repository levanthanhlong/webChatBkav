import { Link } from "react-router-dom";
import { useState } from "react";
import useSignup from "../../hooks/useSignup";

const SignUp = () => {
    const [inputs, setInputs] = useState({
        fullName: "",
        username: "",
        password: "",
        confirmPassword: "",
    });

    const { loading, signup } = useSignup();

    const handleSubmit = async (e) => {
        e.preventDefault();
        await signup(inputs);
    };

    return (
        <div className=" w-full h-screen flex flex-col bg-gray-100">
            {/* Header */}
            <div className="w-full px-8 py-4">
                <img
                    src="/images/logo-deep.png"
                    alt="Logo"
                    width={100}
                    height={40}
                />
            </div>

            {/* Content */}
            <div className="w-full flex flex-row mt-8 justify-center items-center">
                <div className="flex flex-row gap-80">
                    {/* Background Image */}
                    <div className="mt-16 ml-16 md:flex hidden">
                        <img src="public/images/background-signup.png" alt="Background image signin" />
                    </div>

                    {/* Form */}
                    <div className="flex flex-col">
                        <div className="flex flex-row justify-between items-center">
                            <div className="null"></div>
                            <div className="choose-language">
                                <select
                                    name="choose-language"
                                    id="choose-language"
                                    className="border-0 bg-transparent font-roboto text-base font-medium leading-none tracking-wider"
                                >
                                    <option value="vi">Tiếng Việt</option>
                                    <option value="en">English</option>
                                </select>
                            </div>
                            <div className="flex">
                                <div className="btn-signin">
                                    <div className="px-2 py-1 rounded-lg">
                                        <span className="text-blue-500">Đăng nhập</span>
                                    </div>
                                    <div className="line-bottom"></div>
                                </div>
                                <div className="btn-signup">
                                    <div className="content-btn px-2 py-1 rounded-lg">
                                        <span className="text-blue-500">Đăng ký</span>
                                    </div>
                                    <div className="line-bottom"></div>
                                </div>
                            </div>
                        </div>

                        <div className="form flex flex-col mt-16">
                            <div className="">
                                <form className="space-y-4" onSubmit={handleSubmit}>
                                    <div>
                                        <input
                                            type='text'
                                            placeholder='Tên hiển thị'
                                            className='w-full input input-bordered h-10 bg-customBlue text-customGray'
                                            value={inputs.fullName}
                                            onChange={(e) => setInputs({ ...inputs, fullName: e.target.value })}
                                        />
                                    </div>

                                    <div>
                                        <input
                                            type='text'
                                            placeholder='tài khoản'
                                            className='w-full input input-bordered h-10 bg-customBlue text-customGray'
                                            value={inputs.username}
                                            onChange={(e) => setInputs({ ...inputs, username: e.target.value })}
                                        />
                                    </div>

                                    <div>
                                        <input
                                            type='password'
                                            placeholder='Mật khẩu'
                                            className='w-full input input-bordered h-10 bg-customBlue text-customGray'
                                            value={inputs.password}
                                            onChange={(e) => setInputs({ ...inputs, password: e.target.value })}
                                        />
                                    </div>

                                    <div>
                                         <input
                                            type='password'
                                            placeholder='Nhắc lại mật khẩu'
                                            className='w-full input input-bordered h-10 bg-customBlue text-customGray'
                                            value={inputs.confirmPassword}
                                            onChange={(e) => setInputs({ ...inputs, confirmPassword: e.target.value })}
                                        />
                                    </div>
                                    <Link
                                        to={"/login"}
                                        className='text-sm hover:underline hover:text-blue-600 mt-2 inline-block'
                                        href='#'
                                    >
                                        Already have an account?
                                    </Link>

                                    <div>
                                        <button className='bg-customBtn text-white btn btn-block btn-sm mt-2 border border-slate-700' disabled={loading}>
                                            {loading ? <span className='loading loading-spinner'></span> : "Sign Up"}
                                        </button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
export default SignUp;



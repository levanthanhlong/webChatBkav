import { useState } from "react";
import { Link } from "react-router-dom";
import useLogin from "../../hooks/useLogin";
import { BsApple, BsFacebook, BsGoogle } from "react-icons/bs";
import AuthSocialButton from "./AuthSocialButton";
const FormLogin = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const { loading, login } = useLogin();

  const handleSubmit = async (e) => {
    e.preventDefault();
    await login(username, password);
  };

  const socialAction = () => {};
  return (
    <div className=" w-full h-screen flex flex-col bg-gray-100">
      {/* Header */}
      <div className="w-full px-8 py-4">
        <img src="/images/logo-deep.png" alt="Logo" width={100} height={40} />
      </div>

      {/* Content */}
      <div className="w-full flex flex-row mt-8 justify-center items-center">
        <div className="flex flex-row gap-80">
          
          {/* Description */}

          <div className="flex-col justify-center md:flex hidden">
            <div className="relative">
              <div className="absolute inset-0 bg-blue-background bg-cover z-0 top-10 left-10">
                <img
                  src="/images/blue-background.png"
                  height={400}
                  width={400}
                  alt="blue-background"
                />
              </div>
              <div className="absolute inset-0 bg-blue-background bg-cover z-0 top-10 left-10">
                <div className="circle-blur"></div>
              </div>
              <div className="relative z-10 p-4">
                <h2 className="text-black font-normal leading-10 text-4xl">
                  Đăng nhập để
                  <br />
                  kết nối
                </h2>
                <span className="cursor-pointer hover:text-primary-dark">
                  Nếu chưa có tài khoản Đăng ký tại
                  <br />
                  <span className="text-blue-500">đây!</span>
                </span>
              </div>
            </div>
          </div>

          <div className="mt-16 md:flex hidden">
            <img
              src="public/images/background-login.png"
              alt="Background image signin"
            />
          </div>

          {/* Form */}
          <div className="flex flex-col">
            <div className="flex flex-row justify-between items-center">
              <div className="null"></div>
              <div className="choose-language">
                <select
                  name="choose-language"
                  id="choose-language"
                  className="border-0 bg-transparent font-roboto text-base font-medium leading-none tracking-wider"
                >
                  <option value="vi">Tiếng Việt</option>
                  <option value="en">English</option>
                </select>
              </div>
              <div className="flex">
                <div className="btn-signin">
                  <div className="px-2 py-1 rounded-lg">
                    <span className="text-blue-500">Đăng nhập</span>
                  </div>
                  <div className="line-bottom"></div>
                </div>
                <div className="btn-signup">
                  <div className="content-btn px-2 py-1 rounded-lg">
                    <span className="text-blue-500">Đăng ký</span>
                  </div>
                  <div className="line-bottom"></div>
                </div>
              </div>
            </div>

            <div className="form flex flex-col mt-16">
              <div className="form-1">
                <form className="space-y-4" onSubmit={handleSubmit}>
                  <div className="form-control relative">
                    <input
                      type="text"
                      placeholder="Nhập tài khoản"
                      className="w-full input input-bordered h-10 bg-customBlue text-customGray"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                    />
                  </div>
                  <div className="form-control relative">
                    <input
                      type="password"
                      placeholder="***********"
                      className="w-full input input-bordered h-10 bg-customBlue text-customGray"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                  <div className="div-forgot-password text-right">
                    <span className="text-blue-500 cursor-pointer">
                      Quên mật khẩu ?
                    </span>
                  </div>
                  <Link
                    to="/signup"
                    className="text-sm  hover:underline hover:text-blue-600 mt-2 inline-block"
                  >
                    {"Don't"} have an account?
                  </Link>

                  <div>
                    <button
                      className="bg-customBtn text-white btn btn-block btn-sm mt-2"
                      disabled={loading}
                    >
                      {loading ? (
                        <span className="loading loading-spinner "></span>
                      ) : (
                        "Login"
                      )}
                    </button>
                  </div>
                </form>
                <div className="mt-6">
                  <div className="flex items-center">
                    <div className="flex-1 border-t"></div>
                    <div className="px-4">
                      <span>Hoặc tiếp tục với</span>
                    </div>
                    <div className="flex-1 border-t"></div>
                  </div>
                  <div className="mt-6 flex gap-2">
                    <AuthSocialButton
                      icon={BsGoogle}
                      onClick={() => socialAction("google")}
                    />
                    <AuthSocialButton
                      icon={BsApple}
                      onClick={() => socialAction("apple")}
                    />
                    <AuthSocialButton
                      icon={BsFacebook}
                      onClick={() => socialAction("facebook")}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default FormLogin;

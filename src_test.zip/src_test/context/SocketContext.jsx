// // import { createContext, useState, useEffect, useContext } from "react";
// // import { useAuthContext } from "./AuthContext";
// // import io from "socket.io-client";
// import { createContext, useContext} from "react";
// // Tạo context cho socket
// const SocketContext = createContext();

// // Hook tùy chỉnh để sử dụng SocketContext
// export const useSocketContext = () => {
// 	return useContext(SocketContext);
// };

// // Provider component cho SocketContext
// export const SocketContextProvider = ({ children }) => {
// 	// const [socket, setSocket] = useState(null);
// 	// const [onlineUsers, setOnlineUsers] = useState([]);
// 	// const { authUser } = useAuthContext();

// 	// useEffect(() => {
// 	// 	if (authUser) {
// 	// 		// Kết nối tới server socket với userId
// 	// 		const socket = io("", {
// 	// 			query: {
// 	// 				userId: authUser._id,
// 	// 			},
// 	// 		});

// 	// 		setSocket(socket);

// 	// 		// Lắng nghe sự kiện "getOnlineUsers" để cập nhật danh sách người dùng trực tuyến
// 	// 		socket.on("getOnlineUsers", (users) => {
// 	// 			setOnlineUsers(users);
// 	// 		});

// 	// 		// Đóng kết nối khi component unmount
// 	// 		return () => socket.close();
// 	// 	} else {
// 	// 		// Đóng kết nối socket nếu không có người dùng
// 	// 		if (socket) {
// 	// 			socket.close();
// 	// 			setSocket(null);
// 	// 		}
// 	// 	}
// 	// }, [authUser, socket]);

// 	// return (
// 	// 	<SocketContext.Provider value={{ socket, onlineUsers }}>
// 	// 		{children}
// 	// 	</SocketContext.Provider>
// 	// );
// 	return (
// 		<SocketContext.Provider>
// 			{children}	
// 		</SocketContext.Provider>
// 	);
// };

import FormLogin from "../../components/login/FormLogin";

const Login = () => {
  return <FormLogin />;
};
export default Login;

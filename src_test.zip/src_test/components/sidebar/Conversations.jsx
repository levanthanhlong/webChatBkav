import { useEffect, useState } from "react";
import useGetConversations from "../../hooks/useGetConversations";
import Conversation from "./Conversation";

const Conversations = ({ search }) => {
  const { loading: fetchLoading } = useGetConversations(); // only to trigger data fetch
  const [loading, setLoading] = useState(true);
  const [conversations, setConversations] = useState([]);
  const [lastMessages, setLastMessages] = useState({});

  
  
  useEffect(() => {
    const storedConversations = localStorage.getItem("conversations");
    if (storedConversations) {
      setConversations(JSON.parse(storedConversations));
    }

    const fetchLastMessages = () => {
      const updatedLastMessages = {};
      const storedConversations = JSON.parse(localStorage.getItem("conversations"));
      if (storedConversations) {
        storedConversations.forEach(conversation => {
          const messages = JSON.parse(localStorage.getItem(`messages-${conversation.FriendID}`));
          if (messages && messages.length > 0) {
            updatedLastMessages[conversation.FriendID] = messages[messages.length - 1];
          }
        });
      }
      setLastMessages(updatedLastMessages);
    };
   
    fetchLastMessages();

    const interval = setInterval(fetchLastMessages, 100); // Update every 1 second

    setLoading(false);
    return () => clearInterval(interval); // Cleanup interval on unmount
  }, []);

  
  // Filter out conversations with null or undefined FullName
  // and sort the rest by FriendID
  const filteredConversations = conversations
    .filter((conversation) => conversation.FullName)
    .filter((conversation) =>
      search
        ? String(conversation.FullName)
            .toLowerCase()
            .includes(search.toLowerCase())
        : true
    )
    .sort((a, b) => {
      const idA = a.FriendID;
      const idB = b.FriendID;
      if (idA < idB) return -1;
      if (idA > idB) return 1;
      return 0;
    });
    
  return (
    <div className="py-2 flex flex-col overflow-auto">
      {filteredConversations.map((conversation, idx) => (
        <Conversation
          key={conversation.FriendID}
          conversation={conversation}
          lastMessage={lastMessages[conversation.FriendID]} // Get last message
          lastIdx={idx === filteredConversations.length - 1}
        />
      ))}

      {loading || fetchLoading ? (
        <span className="loading loading-spinner mx-auto"></span>
      ) : null}
    </div>
  );
};

export default Conversations;


// import { useEffect, useState } from "react";
// import useGetConversations from "../../hooks/useGetConversations";
// import Conversation from "./Conversation";

// const Conversations = ({ search }) => {
//   const { loading: fetchLoading, conversations } = useGetConversations(); // Now this hook handles fetching messages as well
//   const [loading, setLoading] = useState(true);
//   const [lastMessages, setLastMessages] = useState({});

//   useEffect(() => {
//     const fetchLastMessages = () => {
//       const updatedLastMessages = {};
//       const storedConversations = JSON.parse(localStorage.getItem("conversations"));
//       if (storedConversations) {
//         storedConversations.forEach(conversation => {
//           const messages = JSON.parse(localStorage.getItem(`messages-${conversation.FriendID}`));
//           if (messages && messages.length > 0) {
//             updatedLastMessages[conversation.FriendID] = messages[messages.length - 1];
//           }
//         });
//       }
//       setLastMessages(updatedLastMessages);
//     };

//     fetchLastMessages();

//     const interval = setInterval(fetchLastMessages, 1000); // Update every 1 second

//     setLoading(false);
//     return () => clearInterval(interval); // Cleanup interval on unmount
//   }, []);

//   // Filter out conversations with null or undefined FullName
//   // and sort the rest by FriendID
//   const filteredConversations = conversations
//     .filter((conversation) => conversation.FullName)
//     .filter((conversation) =>
//       search
//         ? String(conversation.FullName)
//             .toLowerCase()
//             .includes(search.toLowerCase())
//         : true
//     )
//     .sort((a, b) => {
//       const idA = a.FriendID;
//       const idB = b.FriendID;
//       if (idA < idB) return -1;
//       if (idA > idB) return 1;
//       return 0;
//     });

//   return (
//     <div className="py-2 flex flex-col overflow-auto">
//       {filteredConversations.map((conversation, idx) => (
//         <Conversation
//           key={conversation.FriendID}
//           conversation={conversation}
//           lastMessage={lastMessages[conversation.FriendID]} // Get last message
//           lastIdx={idx === filteredConversations.length - 1}
//         />
//       ))}

//       {loading || fetchLoading ? (
//         <span className="loading loading-spinner mx-auto"></span>
//       ) : null}
//     </div>
//   );
// };

// export default Conversations;

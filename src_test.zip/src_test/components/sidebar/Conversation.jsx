import useConversation from "../../zustand/useConversation";
import { extractTime } from "../../utils/extractTime"; 

const API_URL = "http://10.2.44.52:8888/api/images"; // API for avatar
const DEFAULT_AVATAR = "/avatar/4bbfc078-ad2d-46a8-b023-a1e30992903d.jpg"; // Default avatar URL

const limitText = (text, maxLength) => {
  text = String(text);
  if (text.length > maxLength) {
    return text.slice(0, maxLength) + "...";
  }
  return text;
};

const Conversation = ({ conversation, lastMessage, lastIdx }) => {
  const { selectedConversation, setSelectedConversation } = useConversation();
  const isSelected = selectedConversation?.FriendID === conversation.FriendID;
  const isOnline = conversation.isOnline;
  const maxLength = 13; // Set maximum length for displayed name and content


  // Limit the length of FullName and Content
  const limitedFullName = limitText(conversation.FullName, maxLength);
  const limitedContent = lastMessage
    ? limitText(lastMessage.Content || lastMessage.Text || "", maxLength)
    : "No messages";

  // Format the time of the last message
  const lastMessageTime = lastMessage ? extractTime(lastMessage.CreatedAt) : "";

  const avatarUrl = `${API_URL}${conversation.Avatar || DEFAULT_AVATAR}`;

  return (
    <>
      <div
        className={`flex gap-2 items-center hover:bg-sky-500 rounded p-2 py-1 cursor-pointer
                ${isSelected ? "bg-sky-500" : ""} `}
        onClick={() => setSelectedConversation(conversation)}
      >
        <div className={`avatar ${isOnline ? "" : ""}`}>
          <div className="w-12 rounded-full">
            <img src={avatarUrl} alt="user avatar" />
          </div>
          <div
            className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${
              isOnline ? "bg-green-500" : "bg-red-500"
            }`}
          ></div>
        </div>

        <div className="flex flex-col flex-1">
          <div className="flex justify-between items-center">
            <p className="font-bold text-black">{limitedFullName}</p>
          </div>
          <div className="flex justify-between">
            <p className="text-black">{limitedContent || "file"}</p>
            <p className="text-gray-500 text-xs">{lastMessageTime}</p>
          </div>
        </div>
      </div>

      {!lastIdx && <div className="divider my-0 py-0 h-1" />}
    </>
  );
};

export default Conversation;



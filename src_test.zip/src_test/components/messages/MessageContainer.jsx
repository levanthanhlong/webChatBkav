// import { useEffect } from "react";
// import useConversation from "../../zustand/useConversation";
// import MessageInput from "./MessageInput";
// import Messages from "./Messages";
// import { TiMessages } from "react-icons/ti";

// const DEFAULT_AVATAR = "/avatar/4bbfc078-ad2d-46a8-b023-a1e30992903d.jpg"; // Default avatar URL

// const MessageContainer = () => {
//   //const API_URL = 'http://127.0.0.1:8888/api/images'; //home api
//   const API_URL = "http://10.2.44.52:8888/api/images";
//   const { selectedConversation, setSelectedConversation } = useConversation();

//   // const isOnline = selectedConversation.isOnline;

//   useEffect(() => {
//     return () => setSelectedConversation(null); // cleanup khi unmount
//   }, [setSelectedConversation]);

//   return (
//     <div className="md:min-w-[450px] flex flex-col w-full bg-white">
//       {!selectedConversation ? (
//         <NoChatSelected />
//       ) : (
//         <>
//           {/* Header */}
//           <div className="flex gap-2 items-center bg-sky-500 rounded p-2 py-1">
//             <div className="w-12 h-12 rounded-full overflow-hidden">
//               <img
//                 src={`${API_URL}${
//                   selectedConversation.Avatar || DEFAULT_AVATAR
//                 }`}
//                 alt="user avatar"
//                 className="h-full w-full object-cover"
//               />
//             </div>
//             <div className="flex gap-3 justify-between">
//               <p className="font-bold text-gray-200">
//                 {selectedConversation.FullName}
//               </p>
//             </div>
//           </div>

//           <Messages />
//           <MessageInput />
//         </>
//       )}
//     </div>
//   );
// };
// export default MessageContainer;

// const NoChatSelected = () => {
//   return (
//     <div className="flex items-center justify-center w-full h-full">
//       <div className="px-4 text-center sm:text-lg md:text-xl text-gray-200 font-semibold flex flex-col items-center gap-2">
//         <TiMessages className="text-3xl md:text-6xl text-center" />

//         <p>Chưa có tin nhắn nào</p>
//       </div>
//     </div>
//   );
// };

import { useEffect } from "react";
import useConversation from "../../zustand/useConversation";
import MessageInput from "./MessageInput";
import Messages from "./Messages";
import { TiMessages } from "react-icons/ti";

const DEFAULT_AVATAR = "/avatar/4bbfc078-ad2d-46a8-b023-a1e30992903d.jpg"; // Default avatar URL

const MessageContainer = () => {
  //const API_URL = 'http://127.0.0.1:8888/api/images'; //home api
  const API_URL = "http://10.2.44.52:8888/api/images";  
  const { selectedConversation, setSelectedConversation } = useConversation();

  // const isOnline = selectedConversation.isOnline;

  useEffect(() => {
    return () => setSelectedConversation(null); // cleanup khi unmount
  }, [setSelectedConversation]);

  return (
    <div className="md:min-w-[450px] flex flex-col w-full bg-white">
      {!selectedConversation ? (
        <NoChatSelected />
      ) : (
        <>
          {/* Header */}
          <div className="flex gap-2 items-center bg-sky-500 rounded p-2 py-1">
            <div className="w-12 h-12 rounded-full overflow-hidden">
              <img
                src={`${API_URL}${
                  selectedConversation.Avatar || DEFAULT_AVATAR
                }`}
                alt="user avatar"
                className="h-full w-full object-cover"
              />
            </div>
            <div className="flex gap-3 justify-between">
              <p className="font-bold text-gray-200">
                {selectedConversation.FullName.length > 50
                  ? selectedConversation.FullName.substring(0, 50) + "..."
                  : selectedConversation.FullName}
              </p>
            </div>
          </div>

          <Messages />
          <MessageInput />
        </>
      )}
    </div>
  );
};
export default MessageContainer;

const NoChatSelected = () => {
  // const { authUser } = useAuthContext();
  return (
    <div className="flex items-center justify-center w-full h-full">
      <div className="px-4 text-center sm:text-lg md:text-xl text-gray-200 font-semibold flex flex-col items-center gap-2">
        <TiMessages className="text-3xl md:text-6xl text-center" />
        
        <p>Chưa có tin nhắn nào</p>
      </div>
    </div>
  );
};
